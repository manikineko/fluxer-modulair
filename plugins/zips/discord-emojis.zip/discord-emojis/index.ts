/*
 * MIT License
 *
 * Copyright (c) 2026 manikineko.nl
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

import type {PluginUIContext, UIComponentDescriptor} from '@fluxer/plugin';

const emojis: Map<string, {id: string; name: string; animated: boolean; available: boolean; requireColons: boolean}> = new Map();
const stickers: Map<string, {id: string; name: string; description?: string; tags?: string[]; type: 'standard' | 'guild'; format: 'png' | 'apng' | 'lottie'}> = new Map();

export async function onLoad(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string; version: string};
	console.log(`Discord Emojis plugin loaded! ID: ${ctx.pluginId}, Version: ${ctx.version}`);
	await loadDefaultEmojis();
}

export async function onEnable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Discord Emojis plugin enabled! ID: ${ctx.pluginId}`);
}

export async function onDisable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Discord Emojis plugin disabled! ID: ${ctx.pluginId}`);
}

export async function onUIComponentRegister(context: PluginUIContext): Promise<void> {
	console.log(`[Discord Emojis] Registering UI component for ${context.pluginId}`);

	// Register a settings panel component for managing emojis and stickers
	const component: UIComponentDescriptor = {
		id: `${context.pluginId}-settings-panel`,
		name: 'Emojis & Stickers Settings',
		component: null, // Would be the actual React component
		location: 'settings',
		priority: 50,
		props: {},
	};

	context.registerComponent();
	console.log('[Discord Emojis] Component registered successfully');
}

export async function onUIComponentUnregister(componentId: string): Promise<void> {
	console.log(`[Discord Emojis] Unregistering UI component: ${componentId}`);
}

async function loadDefaultEmojis(): Promise<void> {
	const defaultEmojis = [
		{id: 'emoji_1', name: 'smile', animated: false, available: true, requireColons: true},
		{id: 'emoji_2', name: 'thumbs_up', animated: false, available: true, requireColons: true},
		{id: 'emoji_3', name: 'party', animated: true, available: true, requireColons: true},
	];

	for (const emoji of defaultEmojis) {
		emojis.set(emoji.id, emoji);
	}

	console.log(`Loaded ${emojis.size} default emojis`);
}

export async function addEmoji(emoji: {id: string; name: string; animated: boolean; available: boolean; requireColons: boolean}): Promise<void> {
	emojis.set(emoji.id, emoji);
}

export async function getEmoji(id: string): Promise<unknown | null> {
	return emojis.get(id) || null;
}

export async function listEmojis(): Promise<Map<string, unknown>> {
	return emojis as unknown as Map<string, unknown>;
}

export async function addSticker(sticker: {id: string; name: string; description?: string; tags?: string[]; type: 'standard' | 'guild'; format: 'png' | 'apng' | 'lottie'}): Promise<void> {
	stickers.set(sticker.id, sticker);
}

export async function getSticker(id: string): Promise<unknown | null> {
	return stickers.get(id) || null;
}

export async function listStickers(): Promise<Map<string, unknown>> {
	return stickers as unknown as Map<string, unknown>;
}

export async function searchEmojis(query: string): Promise<unknown[]> {
	const results: unknown[] = [];
	for (const emoji of emojis.values()) {
		if (emoji.name.toLowerCase().includes(query.toLowerCase())) {
			results.push(emoji);
		}
	}
	return results;
}

export async function searchStickers(query: string): Promise<unknown[]> {
	const results: unknown[] = [];
	for (const sticker of stickers.values()) {
		if (sticker.name.toLowerCase().includes(query.toLowerCase()) || sticker.tags?.some(tag => tag.toLowerCase().includes(query.toLowerCase()))) {
			results.push(sticker);
		}
	}
	return results;
}
