/*
 * MIT License
 *
 * Copyright (c) 2026 manikineko.nl
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

const voiceStates: Map<string, {userId: string; guildId: string; channelId: string; muted: boolean; deafened: boolean; selfMuted: boolean; selfDeafened: boolean}> = new Map();
const voiceChannels: Map<string, Set<string>> = new Map();

export async function onLoad(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string; version: string};
	console.log(`Discord Voice plugin loaded! ID: ${ctx.pluginId}, Version: ${ctx.version}`);
}

export async function onEnable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Discord Voice plugin enabled! ID: ${ctx.pluginId}`);
}

export async function onDisable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Discord Voice plugin disabled! ID: ${ctx.pluginId}`);
}

export async function joinVoiceChannel(userId: string, guildId: string, channelId: string): Promise<void> {
	const voiceState = {
		userId,
		guildId,
		channelId,
		muted: false,
		deafened: false,
		selfMuted: false,
		selfDeafened: false,
	};
	
	voiceStates.set(userId, voiceState);
	
	const channelUsers = voiceChannels.get(channelId) || new Set();
	channelUsers.add(userId);
	voiceChannels.set(channelId, channelUsers);
	
	console.log(`User ${userId} joined voice channel ${channelId}`);
}

export async function leaveVoiceChannel(userId: string): Promise<void> {
	const voiceState = voiceStates.get(userId);
	if (voiceState) {
		const channelUsers = voiceChannels.get(voiceState.channelId);
		if (channelUsers) {
			channelUsers.delete(userId);
			if (channelUsers.size === 0) {
				voiceChannels.delete(voiceState.channelId);
			}
		}
		voiceStates.delete(userId);
		console.log(`User ${userId} left voice channel ${voiceState.channelId}`);
	}
}

export async function getVoiceState(userId: string): Promise<unknown | null> {
	return voiceStates.get(userId) || null;
}

export async function getChannelUsers(channelId: string): Promise<unknown[]> {
	const channelUsers = voiceChannels.get(channelId);
	if (!channelUsers) return [];
	
	const users: unknown[] = [];
	for (const userId of channelUsers) {
		const state = voiceStates.get(userId);
		if (state) {
			users.push(state);
		}
	}
	return users;
}

export async function muteUser(userId: string, serverMute: boolean): Promise<void> {
	const voiceState = voiceStates.get(userId);
	if (voiceState) {
		voiceState.muted = serverMute;
		console.log(`User ${userId} ${serverMute ? 'muted' : 'unmuted'} by server`);
	}
}

export async function selfMuteUser(userId: string, selfMute: boolean): Promise<void> {
	const voiceState = voiceStates.get(userId);
	if (voiceState) {
		voiceState.selfMuted = selfMute;
		console.log(`User ${userId} ${selfMute ? 'self-muted' : 'self-unmuted'}`);
	}
}
