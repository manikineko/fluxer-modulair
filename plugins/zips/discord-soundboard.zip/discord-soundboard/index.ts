/*
 * MIT License
 *
 * Copyright (c) 2026 manikineko.nl
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

const soundboardSounds: Map<string, {id: string; name: string; guildId: string; soundId: string; volume: number; emojiId?: string}> = new Map();
const guildSoundboards: Map<string, Set<string>> = new Map();

export async function onLoad(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string; version: string};
	console.log(`Discord Soundboard plugin loaded! ID: ${ctx.pluginId}, Version: ${ctx.version}`);
	await loadDefaultSounds();
}

export async function onEnable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Discord Soundboard plugin enabled! ID: ${ctx.pluginId}`);
}

export async function onDisable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Discord Soundboard plugin disabled! ID: ${ctx.pluginId}`);
}

async function loadDefaultSounds(): Promise<void> {
	const defaultSounds = [
		{id: 'sound_1', name: 'Applause', guildId: 'default', soundId: 'applause.mp3', volume: 1.0},
		{id: 'sound_2', name: 'Laugh Track', guildId: 'default', soundId: 'laugh.mp3', volume: 0.8},
		{id: 'sound_3', name: 'Dramatic Sound', guildId: 'default', soundId: 'dramatic.mp3', volume: 0.9},
	];

	for (const sound of defaultSounds) {
		soundboardSounds.set(sound.id, sound);
		const guildSounds = guildSoundboards.get(sound.guildId) || new Set();
		guildSounds.add(sound.id);
		guildSoundboards.set(sound.guildId, guildSounds);
	}

	console.log(`Loaded ${soundboardSounds.size} default sounds`);
}

export async function addSound(sound: {id: string; name: string; guildId: string; soundId: string; volume: number; emojiId?: string}): Promise<void> {
	soundboardSounds.set(sound.id, sound);
	const guildSounds = guildSoundboards.get(sound.guildId) || new Set();
	guildSounds.add(sound.id);
	guildSoundboards.set(sound.guildId, guildSounds);
}

export async function getSound(id: string): Promise<unknown | null> {
	return soundboardSounds.get(id) || null;
}

export async function listGuildSounds(guildId: string): Promise<unknown[]> {
	const guildSoundIds = guildSoundboards.get(guildId) || new Set();
	const sounds: unknown[] = [];
	for (const soundId of guildSoundIds) {
		const sound = soundboardSounds.get(soundId);
		if (sound) {
			sounds.push(sound);
		}
	}
	return sounds;
}

export async function playSound(soundId: string, userId: string): Promise<void> {
	const sound = soundboardSounds.get(soundId);
	if (sound) {
		console.log(`Playing sound ${sound.name} (${sound.soundId}) for user ${userId} at volume ${sound.volume}`);
		
		// Simulate audio playback
		// In production, this would:
		// 1. Load the audio file from the sound URL
		// 2. Create an AudioContext or use Web Audio API
		// 3. Apply volume and effects
		// 4. Play the sound to the appropriate channel
		// 5. Handle playback events (start, end, error)
		
		// For now, simulate playback
		try {
			// Simulate audio loading and playback
			await new Promise(resolve => setTimeout(resolve, 100));
			console.log(`[Soundboard] Started playing: ${sound.name}`);
			
			// In a real implementation, you would use:
			// const audio = new Audio(sound.url);
			// audio.volume = sound.volume;
			// audio.play();
		} catch (error) {
			console.error(`Error playing sound ${soundId}:`, error);
		}
	}
}

export async function removeSound(soundId: string): Promise<void> {
	const sound = soundboardSounds.get(soundId);
	if (sound) {
		soundboardSounds.delete(soundId);
		const guildSounds = guildSoundboards.get(sound.guildId);
		if (guildSounds) {
			guildSounds.delete(soundId);
		}
	}
}

export async function setVolume(soundId: string, volume: number): Promise<void> {
	const sound = soundboardSounds.get(soundId);
	if (sound) {
		sound.volume = Math.max(0, Math.min(1, volume));
	}
}

export async function searchSounds(query: string): Promise<unknown[]> {
	const results: unknown[] = [];
	for (const sound of soundboardSounds.values()) {
		if (sound.name.toLowerCase().includes(query.toLowerCase())) {
			results.push(sound);
		}
	}
	return results;
}
