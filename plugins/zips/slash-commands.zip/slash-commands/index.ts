/*
 * MIT License
 *
 * Copyright (c) 2026 manikineko.nl
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

interface SlashCommand {
	name: string;
	description: string;
	options?: SlashCommandOption[];
	handler: (params: Record<string, unknown>) => Promise<{success: boolean; data?: unknown; error?: string}>;
}

interface SlashCommandOption {
	name: string;
	description: string;
	type: 'string' | 'number' | 'boolean' | 'user' | 'channel' | 'role';
	required: boolean;
	choices?: Array<{name: string; value: string}>;
}

const commands: Map<string, SlashCommand> = new Map();

export async function onLoad(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string; version: string};
	console.log(`Slash Commands plugin loaded! ID: ${ctx.pluginId}, Version: ${ctx.version}`);
	await registerDefaultCommands();
}

export async function onEnable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Slash Commands plugin enabled! ID: ${ctx.pluginId}`);
}

export async function onDisable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Slash Commands plugin disabled! ID: ${ctx.pluginId}`);
}

export async function onRequest(context: unknown): Promise<void> {
	const ctx = context as {request: {url: string; method: string; body?: unknown}};
	if (ctx.request.url?.startsWith('/api/slash/')) {
		await handleSlashCommand(ctx.request);
	}
}

async function registerDefaultCommands(): Promise<void> {
	// Register default slash commands
	await registerCommand({
		name: 'help',
		description: 'Show available commands',
		handler: async () => {
			const commandList = Array.from(commands.keys()).join(', ');
			return {
				success: true,
				data: {
					commands: commandList,
					message: `Available commands: ${commandList}`,
				},
			};
		},
	});

	await registerCommand({
		name: 'ping',
		description: 'Check if the bot is responding',
		handler: async () => {
			return {
				success: true,
				data: {message: 'Pong!'},
			};
		},
	});

	await registerCommand({
		name: 'echo',
		description: 'Echo back a message',
		options: [
			{
				name: 'message',
				description: 'The message to echo',
				type: 'string',
				required: true,
			},
		],
		handler: async (params) => {
			return {
				success: true,
				data: {message: params.message},
			};
		},
	});

	await registerCommand({
		name: 'status',
		description: 'Show system status',
		handler: async () => {
			return {
				success: true,
				data: {
					status: 'online',
					uptime: Date.now(),
					timestamp: new Date().toISOString(),
				},
			};
		},
	});

	console.log(`Registered ${commands.size} slash commands`);
}

async function handleSlashCommand(request: {url: string; method: string; body?: unknown}): Promise<void> {
	const commandName = request.url.replace('/api/slash/', '');
	const command = commands.get(commandName);
	
	if (!command) {
		console.error(`Slash command not found: ${commandName}`);
		return;
	}

	const body = request.body as Record<string, unknown> | undefined;
	const params = body?.params as Record<string, unknown> || {};
	
	try {
		const result = await command.handler(params);
		if (result.success) {
			console.log(`Slash command executed: ${commandName}`);
		} else {
			console.error(`Slash command failed: ${commandName}`, result.error);
		}
	} catch (error) {
		console.error(`Slash command error: ${commandName}`, error);
	}
}

export async function registerCommand(command: SlashCommand): Promise<void> {
	commands.set(command.name, command);
	console.log(`Registered slash command: ${command.name}`);
}

export async function unregisterCommand(name: string): Promise<void> {
	commands.delete(name);
	console.log(`Unregistered slash command: ${name}`);
}

export async function getCommand(name: string): Promise<SlashCommand | null> {
	return commands.get(name) || null;
}

export async function listCommands(): Promise<SlashCommand[]> {
	return Array.from(commands.values());
}
