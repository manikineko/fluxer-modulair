/*
 * MIT License
 *
 * Copyright (c) 2026 manikineko.nl
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

import type {PluginUIContext, UIComponentDescriptor} from '@fluxer/plugin';

const activities: Map<string, {type: 'playing' | 'streaming' | 'listening' | 'watching' | 'custom'; name: string; url?: string; details?: string; state?: string; emoji?: {name: string; id: string; animated: boolean}}> = new Map();

export async function onLoad(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string; version: string};
	console.log(`Discord Activities plugin loaded! ID: ${ctx.pluginId}, Version: ${ctx.version}`);
}

export async function onEnable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Discord Activities plugin enabled! ID: ${ctx.pluginId}`);
}

export async function onDisable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Discord Activities plugin disabled! ID: ${ctx.pluginId}`);
}

export async function onUIComponentRegister(context: PluginUIContext): Promise<void> {
	console.log(`[Discord Activities] Registering UI component for ${context.pluginId}`);

	// Register a settings panel component for managing activities
	const component: UIComponentDescriptor = {
		id: `${context.pluginId}-settings-panel`,
		name: 'Activities Settings',
		component: null, // Would be the actual React component
		location: 'settings',
		priority: 50,
		props: {},
	};

	context.registerComponent();
	console.log('[Discord Activities] Component registered successfully');
}

export async function onUIComponentUnregister(componentId: string): Promise<void> {
	console.log(`[Discord Activities] Unregistering UI component: ${componentId}`);
}

export async function startActivity(userId: string, activity: {type: 'playing' | 'streaming' | 'listening' | 'watching' | 'custom'; name: string; url?: string; details?: string; state?: string; emoji?: {name: string; id: string; animated: boolean}}): Promise<void> {
	activities.set(userId, activity);
	console.log(`Started activity for ${userId}: ${activity.type} ${activity.name}`);
}

export async function getActivity(userId: string): Promise<unknown | null> {
	return activities.get(userId) || null;
}

export async function clearActivity(userId: string): Promise<void> {
	activities.delete(userId);
	console.log(`Cleared activity for ${userId}`);
}

export async function getAllActivities(): Promise<Map<string, unknown>> {
	return activities as unknown as Map<string, unknown>;
}

export async function setPlaying(userId: string, name: string, details?: string, state?: string): Promise<void> {
	await startActivity(userId, {type: 'playing', name, details, state});
}

export async function setStreaming(userId: string, name: string, url: string, details?: string): Promise<void> {
	await startActivity(userId, {type: 'streaming', name, url, details});
}

export async function setListening(userId: string, name: string, details?: string): Promise<void> {
	await startActivity(userId, {type: 'listening', name, details});
}

export async function setWatching(userId: string, name: string, details?: string): Promise<void> {
	await startActivity(userId, {type: 'watching', name, details});
}

export async function setCustom(userId: string, name: string, emoji?: {name: string; id: string; animated: boolean}): Promise<void> {
	await startActivity(userId, {type: 'custom', name, emoji});
}
