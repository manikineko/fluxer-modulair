/*
 * MIT License
 *
 * Copyright (c) 2026 manikineko.nl
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// In-memory implementations of ATProto features for the Bluesky plugin
// These mirror the @fluxer/atproto library but are self-contained

interface Blob {
	ref: {ref: {$link: string}};
	mimeType: string;
	size: number;
}

interface Lecture {
	id: string;
	title: string;
	description: string;
	author: string;
	content: string;
	createdAt: string;
	updatedAt: string;
	tags: string[];
	attachments: string[];
}

interface LectureComment {
	id: string;
	lectureId: string;
	author: string;
	content: string;
	createdAt: string;
}

const blobs: Map<string, Blob> = new Map();
const blobData: Map<string, Uint8Array> = new Map();
const lectures: Map<string, Lecture> = new Map();
const lectureComments: Map<string, LectureComment[]> = new Map();
const xrpcHandlers: Map<string, (request: {params: unknown}) => Promise<{success: boolean; data?: unknown; error?: {error: string; message?: string}}>> = new Map();

export async function onLoad(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string; version: string};
	console.log(`Bluesky plugin loaded! ID: ${ctx.pluginId}, Version: ${ctx.version}`);
}

export async function onEnable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Bluesky plugin enabled! ID: ${ctx.pluginId}`);
	await initializeBluesky();
}

export async function onDisable(context: unknown): Promise<void> {
	const ctx = context as {pluginId: string};
	console.log(`Bluesky plugin disabled! ID: ${ctx.pluginId}`);
	await shutdownBluesky();
}

export async function onRequest(context: unknown): Promise<void> {
	const ctx = context as {request: {url: string; method: string}};
	if (ctx.request.url?.startsWith('/xrpc/') || ctx.request.url?.startsWith('/api/bluesky/')) {
		await handleBlueskyRequest(ctx.request);
	}
}

async function initializeBluesky(): Promise<void> {
	console.log('Initializing Bluesky...');
	
	// Register XRPC handlers
	await registerXRPCHandlers();
	
	// Load sample data
	await loadSampleData();
	
	console.log('Bluesky initialized successfully');
}

async function shutdownBluesky(): Promise<void> {
	console.log('Shutting down Bluesky...');
	
	xrpcHandlers.clear();
	
	console.log('Bluesky shut down');
}

async function registerXRPCHandlers(): Promise<void> {
	// Bluesky feed XRPC methods
	xrpcHandlers.set('com.atproto.sync.getBlob', async (request: {params: unknown}) => {
		const params = request.params as {cid: string};
		const blob = blobs.get(params.cid);
		if (blob) {
			return {
				success: true,
				data: blob,
			};
		}
		return {
			success: false,
			error: {
				error: 'BlobNotFound',
				message: 'Blob not found',
			},
		};
	});

	xrpcHandlers.set('com.atproto.repo.uploadBlob', async (request: {params: unknown}) => {
		// Mock blob upload
		const blob: Blob = {
			ref: {ref: {$link: `blob_${Date.now()}`}},
			mimeType: 'application/octet-stream',
			size: 1024,
		};
		blobs.set(blob.ref.ref.$link, blob);
		return {
			success: true,
			data: blob,
		};
	});

	// Lecture XRPC methods
	xrpcHandlers.set('app.bsky.feed.getPost', async (request: {params: unknown}) => {
		const params = request.params as {uri: string};
		// Mock post retrieval
		return {
			success: true,
			data: {
				uri: params.uri,
				cid: 'mock_cid',
				author: {
					did: 'did:example:bluesky',
					handle: 'bluesky',
				},
				record: {
					text: 'Sample post from Bluesky',
					createdAt: new Date().toISOString(),
				},
			},
		};
	});

	xrpcHandlers.set('app.bsky.feed.getTimeline', async () => {
		// Mock timeline
		return {
			success: true,
			data: {
				cursor: 'mock_cursor',
				feed: [
					{
						post: {
							uri: 'at://did:example:bluesky/app.bsky.feed.post/1',
							cid: 'mock_cid_1',
							author: {
								did: 'did:example:user1',
								handle: 'user1',
							},
							record: {
								text: 'Hello from Bluesky!',
								createdAt: new Date().toISOString(),
							},
						},
					},
				],
			},
		};
	});

	console.log(`Registered ${xrpcHandlers.size} XRPC handlers`);
}

async function loadSampleData(): Promise<void> {
	// Load sample lecture
	const sampleLecture: Lecture = {
		id: 'lecture_1',
		title: 'Introduction to ATProto',
		description: 'Learn about the AT Protocol',
		author: 'did:example:bluesky',
		content: 'ATProto is a decentralized social networking protocol...',
		createdAt: new Date().toISOString(),
		updatedAt: new Date().toISOString(),
		tags: ['atproto', 'tutorial'],
		attachments: [],
	};
	
	lectures.set(sampleLecture.id, sampleLecture);
	lectureComments.set(sampleLecture.id, []);
	
	console.log('Loaded sample data');
}

async function handleBlueskyRequest(request: {url: string; method: string}): Promise<void> {
	console.log(`Handling Bluesky request: ${request.method} ${request.url}`);
	
	// Extract NSID from URL
	let nsid = '';
	if (request.url.startsWith('/xrpc/')) {
		nsid = request.url.replace('/xrpc/', '');
	} else if (request.url.startsWith('/api/bluesky/')) {
		nsid = request.url.replace('/api/bluesky/', '');
	}
	
	const handler = xrpcHandlers.get(nsid);
	if (!handler) {
		console.error(`Bluesky handler not found: ${nsid}`);
		return;
	}
	
	const response = await handler({params: {}});
	
	if (response.success) {
		console.log(`Bluesky request successful: ${nsid}`);
	} else {
		console.error(`Bluesky request failed: ${nsid}`, response.error);
	}
}

// Lecture management functions
export async function createLecture(lecture: Omit<Lecture, 'id' | 'createdAt' | 'updatedAt'>): Promise<Lecture> {
	const id = `lecture_${Date.now()}_${Math.random().toString(36).substring(7)}`;
	const now = new Date().toISOString();
	
	const newLecture: Lecture = {
		...lecture,
		id,
		createdAt: now,
		updatedAt: now,
	};
	
	lectures.set(id, newLecture);
	lectureComments.set(id, []);
	
	return newLecture;
}

export async function getLecture(id: string): Promise<Lecture | null> {
	return lectures.get(id) || null;
}

export async function listLectures(author?: string, tags?: string[]): Promise<Lecture[]> {
	let lectureList = Array.from(lectures.values());
	
	if (author) {
		lectureList = lectureList.filter(l => l.author === author);
	}
	
	if (tags && tags.length > 0) {
		lectureList = lectureList.filter(l => 
			tags.some(tag => l.tags.includes(tag))
		);
	}
	
	return lectureList.sort((a, b) => 
		new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
	);
}

export async function addComment(lectureId: string, comment: Omit<LectureComment, 'id' | 'createdAt'>): Promise<LectureComment> {
	const id = `comment_${Date.now()}_${Math.random().toString(36).substring(7)}`;
	const newComment: LectureComment = {
		...comment,
		id,
		createdAt: new Date().toISOString(),
	};
	
	const comments = lectureComments.get(lectureId) || [];
	comments.push(newComment);
	lectureComments.set(lectureId, comments);
	
	return newComment;
}

export async function getComments(lectureId: string): Promise<LectureComment[]> {
	return lectureComments.get(lectureId) || [];
}

// Blob management functions
export async function uploadBlob(data: Uint8Array, mimeType: string): Promise<Blob> {
	const hash = `blob_${Date.now()}_${Math.random().toString(36).substring(7)}`;
	
	const blob: Blob = {
		ref: {ref: {$link: hash}},
		mimeType,
		size: data.length,
	};
	
	blobs.set(hash, blob);
	blobData.set(hash, data);
	
	return blob;
}

export async function getBlob(hash: string): Promise<Blob | null> {
	return blobs.get(hash) || null;
}

export async function getBlobData(hash: string): Promise<Uint8Array | null> {
	return blobData.get(hash) || null;
}
